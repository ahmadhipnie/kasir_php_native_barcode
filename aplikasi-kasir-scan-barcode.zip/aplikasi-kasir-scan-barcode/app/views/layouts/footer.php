<footer class="content-footer footer bg-footer-theme">
    <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
        <div class="mb-2 mb-md-0">
            &copy; <script>
                document.write(new Date().getFullYear());
            </script>
            <span class="fw-semibold"><?= APP_NAME ?></span> v<?= APP_VERSION ?>
        </div>
        <div>
            <span class="text-muted">Sistem Point of Sale</span>
        </div>
    </div>
</footer>