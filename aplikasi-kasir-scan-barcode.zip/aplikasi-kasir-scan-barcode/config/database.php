<?php

return [
    'host' => 'localhost',
    'database' => 'db_kasir_barcode',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4'
];
