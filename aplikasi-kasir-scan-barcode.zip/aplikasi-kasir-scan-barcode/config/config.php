<?php

define('BASE_URL', '/');
define('APP_NAME', 'Aplikasi Kasir');
define('APP_VERSION', '2.0.0');

date_default_timezone_set('Asia/Jakarta');

ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);
